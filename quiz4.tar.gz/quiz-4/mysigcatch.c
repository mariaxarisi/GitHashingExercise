#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void sigint_handler(int sig) {
    printf("\nSIGINT signal caught!\n");
    exit(0);
}

int main() {

    if (signal(SIGINT, sigint_handler) == SIG_ERR) {
        perror("Error: signal() failed");
        exit(EXIT_FAILURE);
    }

    printf("Press Ctrl+C to exit.\n");

    while (1) {
        printf("Running... Press Ctrl+C to exit.\n");
        sleep(2);
    }

    return 0;
}
