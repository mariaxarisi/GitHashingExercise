#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

int count = 0;

void sigint_handler(int sig) {
    count++;
    printf("\nCaught SIGINT (Signal Number: %d)!\n", sig);

    if (count == 2) {
        printf("Restoring default SIGINT behavior.\n");
        if (signal(SIGINT, SIG_DFL) == SIG_ERR) {
        	perror("Error: signal() failed");
        	exit(EXIT_FAILURE);
    	}
    }
}

int main() {

    if (signal(SIGINT, sigint_handler) == SIG_ERR) {
        perror("Error: signal() failed");
        exit(EXIT_FAILURE);
    }

    printf("Press Ctrl+C to send a SIGINT signal...\n");

    while (1) {
        printf("Running...Press Ctrl+C to send a SIGINT signal...\n");
	sleep(2);
    }

    return 0;
}
